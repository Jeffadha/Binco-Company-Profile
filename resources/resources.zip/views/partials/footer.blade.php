<footer class="bg-white border-top py-3">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <span class="text-muted">&copy; {{ date('Y') }}</span>
            </div>
            <div>
                <span class="text-muted"></span>
            </div>
        </div>
    </div>
</footer>
