<header class="bg-white border-bottom sticky-top">
    <div class="d-flex align-items-center justify-content-between p-3">
        <!-- Mobile Toggle Button -->
        <button id="sidebarToggle" class="btn d-lg-none">
            <i class="bi bi-list fs-4"></i>
        </button>

        <!-- Header Title -->
        <h1 class="h5 mb-0">@yield('title', 'Dashboard')</h1>
    </div>
</header>
